<?php declare(strict_types=1);

namespace OndraM\CiDetector\Exception;

class CiNotDetectedException extends \RuntimeException
{
}
