---
name: "Bug report"
about: 'Report a general library issue. Please ensure your version is still supported: https://laravel.com/docs/releases#support-policy'
---

- Sail Version: #.#.#
- Laravel Version: #.#.#
- PHP Version: #.#.#
- Database Driver & Version:

### Description:


### Steps To Reproduce:
