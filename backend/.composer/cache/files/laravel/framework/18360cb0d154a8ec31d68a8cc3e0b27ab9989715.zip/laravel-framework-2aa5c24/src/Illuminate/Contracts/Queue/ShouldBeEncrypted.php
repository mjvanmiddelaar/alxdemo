<?php

namespace Illuminate\Contracts\Queue;

interface ShouldBeEncrypted
{
    //
}
