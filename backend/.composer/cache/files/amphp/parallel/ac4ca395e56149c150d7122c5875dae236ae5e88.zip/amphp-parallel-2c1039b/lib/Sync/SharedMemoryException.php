<?php

namespace Amp\Parallel\Sync;

class SharedMemoryException extends ParcelException
{
}
