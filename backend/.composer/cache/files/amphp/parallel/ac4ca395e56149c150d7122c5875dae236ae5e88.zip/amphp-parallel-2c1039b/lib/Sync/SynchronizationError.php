<?php

namespace Amp\Parallel\Sync;

class SynchronizationError extends \Error
{
}
