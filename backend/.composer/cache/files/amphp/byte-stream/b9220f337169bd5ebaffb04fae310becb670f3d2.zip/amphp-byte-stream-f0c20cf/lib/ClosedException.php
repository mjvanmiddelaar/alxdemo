<?php

namespace Amp\ByteStream;

final class ClosedException extends StreamException
{
}
